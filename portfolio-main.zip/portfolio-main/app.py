from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import joblib
import pandas as pd

app = FastAPI()

# Load the model
model = joblib.load('shopping_trends_model.joblib')

# Define the column names and expected categories
COLUMN_NAMES = [
    "Age",
    "Review Rating",
    "Previous Purchases",
    "Gender",
    "Item Purchased",
    "Category",
    "Location",
    "Size",
    "Color",
    "Season",
    "Subscription Status",
    "Payment Method",
    "Shipping Type",
    "Discount Applied",
    "Promo Code Used",
    "Preferred Payment Method",
    "Frequency of Purchases"
]

EXPECTED_CATEGORIES = {
    "Gender": ["Male", "Female"],
    "Item Purchased": ["Clothing", "Footwear", "Accessories", "Outerwear"],
    "Category": ["Accessories", "Clothing", "Footwear", "Outerwear"],
    "Season": ["Summer", "Winter", "Spring", "Fall"],
    "Payment Method": ["Credit Card", "Debit Card", "Cash"],
}

class ShoppingData(BaseModel):
    Age: int
    Review_Rating: float
    Previous_Purchases: int
    Gender: str
    Item_Purchased: str
    Category: str
    Location: str
    Size: str
    Color: str
    Season: str
    Subscription_Status: str
    Payment_Method: str
    Shipping_Type: str
    Discount_Applied: str
    Promo_Code_Used: str
    Preferred_Payment_Method: str
    Frequency_of_Purchases: str

@app.get("/")
def read_root():
    return {"message": "Shopping Trends Prediction API"}

@app.post("/predict")
async def predict(data: ShoppingData):
    try:
        # Strictly validate categorical inputs
        for key, valid_values in EXPECTED_CATEGORIES.items():
            attr = getattr(data, key.replace(" ", "_"))
            if attr not in valid_values:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid value for '{key}'. Expected one of {valid_values}, but got '{attr}'."
                )

        # Convert input to DataFrame
        features = pd.DataFrame([[
            data.Age,
            data.Review_Rating,
            data.Previous_Purchases,
            data.Gender,
            data.Item_Purchased,
            data.Category,
            data.Location,
            data.Size,
            data.Color,
            data.Season,
            data.Subscription_Status,
            data.Payment_Method,
            data.Shipping_Type,
            data.Discount_Applied,
            data.Promo_Code_Used,
            data.Preferred_Payment_Method,
            data.Frequency_of_Purchases
        ]], columns=COLUMN_NAMES)

        # Predict using the model
        prediction = model.predict(features)
        return {"prediction": int(prediction[0])}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))