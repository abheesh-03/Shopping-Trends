import streamlit as st
import requests

st.title('Shopping Trends Prediction')

# User input form
with st.form("prediction_form"):
    # Numeric inputs
    age = st.number_input('Age', min_value=18, max_value=100, value=25)
    review_rating = st.slider('Review Rating', 1.0, 5.0, 3.0)
    previous_purchases = st.number_input('Previous Purchases', min_value=0, value=1)
    
    # Categorical inputs
    gender = st.selectbox('Gender', ['Male', 'Female'])
    item_purchased = st.text_input('Item Purchased', 'Laptop')
    category = st.selectbox('Category', ['Clothing', 'Footwear', 'Accessories', 'Outerwear'])
    location = st.text_input('Location', 'Urban')
    size = st.text_input('Size', 'Medium')
    color = st.text_input('Color', 'Black')
    season = st.selectbox('Season', ['Summer', 'Winter', 'Spring', 'Fall'])
    subscription_status = st.text_input('Subscription Status', 'Active')
    payment_method = st.selectbox('Payment Method', ['Credit Card', 'Debit Card', 'Cash'])
    shipping_type = st.text_input('Shipping Type', 'Express')
    discount_applied = st.text_input('Discount Applied', 'Yes')
    promo_code_used = st.text_input('Promo Code Used', 'No')
    preferred_payment_method = st.text_input('Preferred Payment Method', 'Credit Card')
    frequency_of_purchases = st.text_input('Frequency of Purchases', 'Weekly')
    
    # Form submission button
    submit = st.form_submit_button("Predict")

if submit:
    # Prepare input data
    input_data = {
        'Age': age,
        'Review_Rating': review_rating,
        'Previous_Purchases': previous_purchases,
        'Gender': gender,
        'Item_Purchased': item_purchased,
        'Category': category,
        'Location': location,
        'Size': size,
        'Color': color,
        'Season': season,
        'Subscription_Status': subscription_status,
        'Payment_Method': payment_method,
        'Shipping_Type': shipping_type,
        'Discount_Applied': discount_applied,
        'Promo_Code_Used': promo_code_used,
        'Preferred_Payment_Method': preferred_payment_method,
        'Frequency_of_Purchases': frequency_of_purchases
    }
    
    try:
        # Correct API endpoint
        api_url = "http://127.0.0.1:8000/predict"
        response = requests.post(api_url, json=input_data)
        
        if response.status_code == 200:
            prediction = response.json()
            st.success(f'Prediction: {prediction["prediction"]}')
        else:
            st.error(f'Error getting prediction: {response.status_code} - {response.text}')
    except Exception as e:
        st.error(f'Error connecting to the service: {str(e)}')